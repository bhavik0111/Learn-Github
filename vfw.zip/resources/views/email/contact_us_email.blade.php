<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
    <body>
        <table>
            <tr>
                <td>Hi Vishwakarma,</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td colspan="2" align="left">Following are the Inquiry Contact detail.</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <th align="left">Name :</th>
                <td align="left">{{ $name }}</td>
            </tr>
            <tr>
                <th align="left">Email :</th>
                <td align="left">{{ $email }}</td>
            </tr>
            <tr>
                <th align="left">Phone :</th>
                <td align="left">{{ $phone }}</td>
            </tr>
            <tr>
                <th align="left">Message :</th>
                <td align="left">{{ $messages }}</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td align="left">Thanks.</td>
            </tr>
        </table>
    </body>
</html>


