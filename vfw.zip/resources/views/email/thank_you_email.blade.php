<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
    <body>
        <table>
            <tr>
                <td>Hi {{ $name }},</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td colspan="2" align="left">THANK YOU FOR CONTACT VISHWAKARMA FURNITURE WORK.</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td align="left">we will contact you soon.</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td align="left">Thanks.</td>
            </tr>
        </table>
    </body>
</html>


