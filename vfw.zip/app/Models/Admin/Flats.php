<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Flats extends Model
{
    use HasFactory;
    protected $table = 'all_flats';

    protected $fillable = [
        'flats_type',
        'image',
        'description',
        'status',
    ];
}
