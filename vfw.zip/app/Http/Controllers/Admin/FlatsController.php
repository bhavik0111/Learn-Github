<?php

namespace App\Http\Controllers\Admin;

use App\Models\Admin\Flats;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class FlatsController extends Controller
{
    protected $dirPath = 'admin/img/flats_image/';

    public function create(){

        return view('admin.flats.create');
    }

    public function store(Request $request){

        $request->validate([
            'flats_type'  => 'required',
            'image' => 'required',
            'status' => 'required'
        ]);

        $flat = new Flats;
        $flat->flats_type = $request->flats_type;
        $flat->title = $request->title;
        $flat->description = $request->description;
        $flat->status = $request->status;

        if ($request->has('image')) {
            $image = $request->file('image'); // name of your input field
            $image_name = rand() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path($this->dirPath), $image_name); // for store in folder
            $flat->image = $this->dirPath . $image_name; // for store in database
        }

        $flat->save();
        return redirect()->route('admin.flats.index')->with('success', 'Record Successfully Inserted');
    }

    public function index(){

        $flats = Flats::get();
        return view('admin.flats.index',compact('flats'));
    }

    public function edit($id){

        $flat = Flats::find($id);
            if (empty($flat)) {
                return redirect()->route('admin.flats.index');
            }
            // dd($flat);
        return view('admin.flats.edit',compact('flat'));
    }

    public function update(Request $request,$id){

        $request->validate([
            'image' => 'required_if:old_image,=,null',
            'status' => 'required'
        ]);

        $flat = Flats::find($id);
        $flat->flats_type = $request->flats_type;
        $flat->title = $request->title;
        $flat->description = $request->description;
        $flat->status = $request->status;
        if ($request->has('image')) {
            if (file_exists(public_path($flat->image))) {
                @unlink(public_path($flat->image));
            }
            $image = $request->file('image'); // name of your input field
            $image_name = rand() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path($this->dirPath), $image_name); // for store in folder
            $flat->image = $this->dirPath . $image_name; // for store in database
        }

        $flat->save();
        return redirect()->route('admin.flats.index')->with('success', 'Record Successfully Updated');
    }

    public function destroy($id){

        $flat = Flats::where('id', $id)->get()->first();

        if (file_exists(public_path($flat->image))) {
            @unlink(public_path($flat->image));
        }

        $flat->delete();
        return redirect()->route('admin.flats.index')->with('success', 'Record Deleted');
    }
}
